# Jurnal Harian Android

Project Android WebView untuk aplikasi Jurnal Harian.

## Build otomatis di GitHub
1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini.
3. Push ke branch `main` atau `master`.
4. Buka tab **Actions**.
5. Pilih workflow **Build Jurnal Harian APK**.
6. Setelah selesai, buka hasil workflow dan download artifact **JurnalHarian-debug-apk**.
7. Extract ZIP artifact, lalu install `app-debug.apk` di Android.

Workflow juga bisa dijalankan manual dari **Actions → Build Jurnal Harian APK → Run workflow**.

Data jurnal disimpan oleh WebView menggunakan localStorage, sehingga checklist, catatan, XP, level, streak, dan data harian tetap tersimpan di perangkat.
